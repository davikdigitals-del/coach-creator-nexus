-- Coursevia admin revenue rules + learner payment methods

create table if not exists public.payment_methods (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text default 'paystack',
  method_type text default 'card',
  brand text,
  last4 text,
  exp_month integer,
  exp_year integer,
  cardholder_name text,
  is_default boolean default false,
  created_at timestamptz default now()
);

alter table public.payment_methods enable row level security;

drop policy if exists "Users manage own payment methods" on public.payment_methods;
create policy "Users manage own payment methods"
on public.payment_methods
for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

alter table public.payments add column if not exists reference text;
alter table public.payments add column if not exists metadata jsonb;
create unique index if not exists payments_reference_key on public.payments(reference) where reference is not null;

alter table public.wallets add column if not exists pending_balance numeric default 0;
alter table public.wallets add column if not exists available_balance numeric default 0;

comment on table public.payment_methods is 'Saved learner card metadata for platform checkout UI. Do not store full PAN or CVV.';
