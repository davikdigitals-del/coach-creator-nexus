-- Coursevia company consolidated auth, onboarding, booking, payment, and payout alignment
create extension if not exists pgcrypto;

-- Safe helper ---------------------------------------------------------------
create or replace function public.has_role(_user_id uuid, _role text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles ur
    where ur.user_id = _user_id
      and ur.role::text = _role
  );
$$;

-- Profiles / roles alignment ------------------------------------------------
alter table if exists public.profiles
  add column if not exists email text,
  add column if not exists role public.app_role,
  add column if not exists phone text,
  add column if not exists country text,
  add column if not exists city text,
  add column if not exists bio text,
  add column if not exists profession text,
  add column if not exists experience text,
  add column if not exists certification text,
  add column if not exists display_name text,
  add column if not exists status text default 'active',
  add column if not exists onboarding_completed boolean default false,
  add column if not exists profile_slug text,
  add column if not exists specialization_type text,
  add column if not exists specialization_slug text,
  add column if not exists business_name text,
  add column if not exists business_email text,
  add column if not exists business_phone text,
  add column if not exists business_website text,
  add column if not exists business_address text,
  add column if not exists business_description text,
  add column if not exists learner_goal text,
  add column if not exists learner_looking_forward text;

create unique index if not exists profiles_profile_slug_key on public.profiles(profile_slug) where profile_slug is not null;
create unique index if not exists user_roles_user_id_role_key on public.user_roles(user_id, role);
create unique index if not exists wallets_user_id_unique on public.wallets(user_id);
create unique index if not exists subscriptions_user_id_unique on public.subscriptions(user_id);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_role public.app_role;
  v_full_name text;
  v_avatar text;
begin
  v_role := coalesce(
    nullif(new.raw_user_meta_data->>'requested_role', '')::public.app_role,
    nullif(new.raw_user_meta_data->>'role', '')::public.app_role,
    'learner'::public.app_role
  );

  v_full_name := coalesce(
    nullif(trim(new.raw_user_meta_data->>'full_name'), ''),
    nullif(trim(new.raw_user_meta_data->>'name'), ''),
    split_part(coalesce(new.email, 'User'), '@', 1)
  );

  v_avatar := coalesce(
    nullif(trim(new.raw_user_meta_data->>'avatar_url'), ''),
    nullif(trim(new.raw_user_meta_data->>'picture'), ''),
    null
  );

  insert into public.profiles (user_id, email, full_name, display_name, avatar_url, role, onboarding_completed, status)
  values (new.id, new.email, v_full_name, v_full_name, v_avatar, v_role, false, 'active')
  on conflict (user_id) do update
    set email = excluded.email,
        full_name = coalesce(nullif(public.profiles.full_name, ''), excluded.full_name),
        display_name = coalesce(nullif(public.profiles.display_name, ''), excluded.display_name),
        avatar_url = coalesce(public.profiles.avatar_url, excluded.avatar_url),
        role = case
          when public.profiles.role is null or public.profiles.role = 'learner' then excluded.role
          else public.profiles.role
        end,
        status = coalesce(public.profiles.status, 'active');

  insert into public.user_roles (user_id, role)
  values (new.id, v_role)
  on conflict (user_id, role) do nothing;

  insert into public.wallets (user_id, currency, balance, pending_balance, available_balance)
  values (new.id, 'USD', 0, 0, 0)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.ensure_my_profile_and_role(p_requested_role public.app_role default null)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user auth.users%rowtype;
  v_role public.app_role;
  v_full_name text;
  v_avatar text;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  select * into v_user from auth.users where id = auth.uid();
  if not found then
    raise exception 'Auth user not found';
  end if;

  v_role := coalesce(
    p_requested_role,
    nullif(v_user.raw_user_meta_data->>'requested_role', '')::public.app_role,
    nullif(v_user.raw_user_meta_data->>'role', '')::public.app_role,
    'learner'::public.app_role
  );

  v_full_name := coalesce(
    nullif(trim(v_user.raw_user_meta_data->>'full_name'), ''),
    nullif(trim(v_user.raw_user_meta_data->>'name'), ''),
    split_part(coalesce(v_user.email, 'User'), '@', 1)
  );

  v_avatar := coalesce(
    nullif(trim(v_user.raw_user_meta_data->>'avatar_url'), ''),
    nullif(trim(v_user.raw_user_meta_data->>'picture'), ''),
    null
  );

  insert into public.profiles (user_id, email, full_name, display_name, avatar_url, role, onboarding_completed, status)
  values (auth.uid(), v_user.email, v_full_name, v_full_name, v_avatar, v_role, false, 'active')
  on conflict (user_id) do update
    set email = excluded.email,
        full_name = coalesce(nullif(public.profiles.full_name, ''), excluded.full_name),
        display_name = coalesce(nullif(public.profiles.display_name, ''), excluded.display_name),
        avatar_url = coalesce(public.profiles.avatar_url, excluded.avatar_url),
        role = case
          when public.profiles.role is null or public.profiles.role = 'learner' or p_requested_role is not null then v_role
          else public.profiles.role
        end,
        status = coalesce(public.profiles.status, 'active');

  insert into public.user_roles (user_id, role)
  values (auth.uid(), v_role)
  on conflict (user_id, role) do nothing;

  insert into public.wallets (user_id, currency, balance, pending_balance, available_balance)
  values (auth.uid(), 'USD', 0, 0, 0)
  on conflict (user_id) do nothing;

  return jsonb_build_object('ok', true, 'role', v_role);
end;
$$;

grant execute on function public.ensure_my_profile_and_role(public.app_role) to authenticated;

create or replace function public.complete_onboarding(
  p_role public.app_role,
  p_full_name text default null,
  p_display_name text default null,
  p_phone text default null,
  p_country text default null,
  p_city text default null,
  p_bio text default null,
  p_profession text default null,
  p_experience text default null,
  p_certification text default null,
  p_specialization_type text default null,
  p_specialization_slug text default null,
  p_business_name text default null,
  p_business_email text default null,
  p_business_phone text default null,
  p_business_website text default null,
  p_business_address text default null,
  p_business_description text default null,
  p_learner_goal text default null,
  p_learner_looking_forward text default null,
  p_profile_slug text default null,
  p_email text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  perform public.ensure_my_profile_and_role(p_role);

  update public.profiles
  set role = p_role,
      email = coalesce(nullif(trim(p_email), ''), email),
      full_name = coalesce(nullif(trim(p_full_name), ''), full_name),
      display_name = coalesce(nullif(trim(p_display_name), ''), display_name),
      phone = nullif(trim(p_phone), ''),
      country = nullif(trim(p_country), ''),
      city = nullif(trim(p_city), ''),
      bio = nullif(trim(p_bio), ''),
      profession = nullif(trim(p_profession), ''),
      experience = nullif(trim(p_experience), ''),
      certification = nullif(trim(p_certification), ''),
      specialization_type = nullif(trim(p_specialization_type), ''),
      specialization_slug = nullif(trim(p_specialization_slug), ''),
      business_name = nullif(trim(p_business_name), ''),
      business_email = nullif(trim(p_business_email), ''),
      business_phone = nullif(trim(p_business_phone), ''),
      business_website = nullif(trim(p_business_website), ''),
      business_address = nullif(trim(p_business_address), ''),
      business_description = nullif(trim(p_business_description), ''),
      learner_goal = nullif(trim(p_learner_goal), ''),
      learner_looking_forward = nullif(trim(p_learner_looking_forward), ''),
      profile_slug = nullif(trim(p_profile_slug), ''),
      onboarding_completed = true,
      status = 'active'
  where user_id = auth.uid();

  insert into public.user_roles (user_id, role)
  values (auth.uid(), p_role)
  on conflict (user_id, role) do nothing;

  return jsonb_build_object('ok', true, 'role', p_role);
end;
$$;

grant execute on function public.complete_onboarding(public.app_role, text, text, text, text, text, text, text, text, text, text, text, text, text, text, text, text, text, text, text, text, text) to authenticated;

update public.profiles p
set role = ur.role
from (
  select user_id, max(role)::public.app_role as role
  from public.user_roles
  group by user_id
) ur
where p.user_id = ur.user_id
  and (p.role is null or p.role = 'learner');

insert into public.user_roles (user_id, role)
select p.user_id, p.role
from public.profiles p
where p.role is not null
on conflict (user_id, role) do nothing;

-- Banking / payout ----------------------------------------------------------
create table if not exists public.payment_methods (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text default 'paystack',
  method_type text default 'card',
  brand text,
  last4 text,
  exp_month integer,
  exp_year integer,
  cardholder_name text,
  is_default boolean default false,
  created_at timestamptz default now()
);

alter table public.payment_methods enable row level security;
drop policy if exists "Users manage own payment methods" on public.payment_methods;
create policy "Users manage own payment methods" on public.payment_methods for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.bank_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  bank_name text,
  account_name text,
  account_number text,
  swift_code text,
  country text,
  country_code text,
  bank_code text,
  currency text,
  is_default boolean default false,
  created_at timestamptz not null default now()
);

alter table public.bank_accounts enable row level security;
drop policy if exists "Users can manage own bank accounts" on public.bank_accounts;
create policy "Users can manage own bank accounts" on public.bank_accounts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create table if not exists public.bank_directory (
  id uuid primary key default gen_random_uuid(),
  country text not null,
  country_code text,
  bank_name text not null,
  bank_code text,
  swift_code text,
  provider text default 'manual',
  metadata jsonb default '{}'::jsonb,
  supports_payout boolean not null default true,
  supports_account_resolve boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table if exists public.bank_directory
  add column if not exists provider text default 'manual',
  add column if not exists metadata jsonb default '{}'::jsonb,
  add column if not exists supports_payout boolean not null default true,
  add column if not exists supports_account_resolve boolean not null default false;

create unique index if not exists bank_directory_country_bank_unique on public.bank_directory (coalesce(country_code, ''), lower(bank_name));
alter table public.bank_directory enable row level security;
drop policy if exists "Authenticated users can read bank directory" on public.bank_directory;
create policy "Authenticated users can read bank directory" on public.bank_directory for select to authenticated using (is_active = true);
drop policy if exists "Admins can manage bank directory" on public.bank_directory;
create policy "Admins can manage bank directory" on public.bank_directory for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

create or replace function public.search_bank_directory(p_country_code text default null, p_query text default null, p_limit integer default 100)
returns table (id uuid, country text, country_code text, bank_name text, bank_code text, swift_code text)
language sql
security definer
set search_path = public
stable
as $$
  select bd.id, bd.country, bd.country_code, bd.bank_name, bd.bank_code, bd.swift_code
  from public.bank_directory bd
  where bd.is_active = true
    and (
      p_country_code is null
      or trim(p_country_code) = ''
      or upper(coalesce(bd.country_code, '')) = upper(trim(p_country_code))
    )
    and (p_query is null or trim(p_query) = '' or bd.bank_name ilike '%' || trim(p_query) || '%' or coalesce(bd.swift_code, '') ilike '%' || trim(p_query) || '%')
  order by bd.country, bd.bank_name
  limit greatest(1, least(coalesce(p_limit, 100), 250));
$$;
grant execute on function public.search_bank_directory(text, text, integer) to authenticated;

create or replace function public.save_bank_directory_entry(p_country_code text, p_country text, p_bank_name text, p_swift_code text default null)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare v_id uuid;
begin
  insert into public.bank_directory (country, country_code, bank_name, swift_code, provider, metadata, supports_payout, supports_account_resolve)
  values (coalesce(nullif(trim(p_country), ''), coalesce(nullif(trim(p_country_code), ''), 'Unknown')), nullif(trim(p_country_code), ''), trim(p_bank_name), nullif(trim(p_swift_code), ''))
  on conflict (coalesce(country_code, ''), lower(bank_name)) do update
    set swift_code = coalesce(excluded.swift_code, public.bank_directory.swift_code),
        provider = coalesce(public.bank_directory.provider, excluded.provider, 'manual'),
        metadata = coalesce(public.bank_directory.metadata, excluded.metadata, '{}'::jsonb),
        supports_payout = true,
        supports_account_resolve = coalesce(public.bank_directory.supports_account_resolve, false),
        updated_at = now(),
        is_active = true
  returning id into v_id;
  return v_id;
end;
$$;
grant execute on function public.save_bank_directory_entry(text, text, text, text) to authenticated;

-- Provider services / booking ----------------------------------------------
create unique index if not exists coach_profiles_user_id_unique_idx on public.coach_profiles(user_id);

alter table if exists public.coach_services
  alter column duration_minutes set default 60;

alter table if exists public.coach_services
  alter column is_active set default true;

update public.coach_services
set is_active = true
where is_active is null;

alter table public.coach_services enable row level security;
drop policy if exists "Services viewable by everyone" on public.coach_services;
create policy "Services viewable by everyone" on public.coach_services for select using (coalesce(is_active, true) = true or exists (select 1 from public.coach_profiles cp where cp.id = coach_id and cp.user_id = auth.uid()) or public.has_role(auth.uid(), 'admin'));
drop policy if exists "Coaches can manage own services" on public.coach_services;
create policy "Coaches can manage own services" on public.coach_services for all to authenticated using (exists (select 1 from public.coach_profiles cp where cp.id = coach_id and cp.user_id = auth.uid()) or public.has_role(auth.uid(), 'admin')) with check (exists (select 1 from public.coach_profiles cp where cp.id = coach_id and cp.user_id = auth.uid()) or public.has_role(auth.uid(), 'admin'));

create or replace function public.get_or_create_provider_profile()
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare v_profile_id uuid;
begin
  select id into v_profile_id from public.coach_profiles where user_id = auth.uid() limit 1;
  if v_profile_id is null then
    insert into public.coach_profiles (user_id, hourly_rate, rating, total_reviews, total_students, is_verified, is_active)
    values (auth.uid(), 0, 5, 0, 0, false, true)
    on conflict (user_id) do update set updated_at = now()
    returning id into v_profile_id;
  end if;
  return v_profile_id;
end;
$$;
grant execute on function public.get_or_create_provider_profile() to authenticated;

create or replace function public.upsert_provider_service(p_service_id uuid default null, p_title text default null, p_description text default null, p_price numeric default 0, p_duration_minutes integer default 60, p_is_active boolean default true)
returns public.coach_services
language plpgsql
security definer
set search_path = public
as $$
declare v_profile_id uuid; v_service public.coach_services;
begin
  v_profile_id := public.get_or_create_provider_profile();
  if p_service_id is null then
    insert into public.coach_services (coach_id, title, description, price, duration_minutes, is_active)
    values (v_profile_id, trim(p_title), nullif(trim(p_description), ''), greatest(coalesce(p_price, 0), 0), greatest(coalesce(p_duration_minutes, 60), 15), coalesce(p_is_active, true))
    returning * into v_service;
  else
    update public.coach_services
    set title = trim(p_title),
        description = nullif(trim(p_description), ''),
        price = greatest(coalesce(p_price, 0), 0),
        duration_minutes = greatest(coalesce(p_duration_minutes, 60), 15),
        is_active = coalesce(p_is_active, true)
    where id = p_service_id and coach_id = v_profile_id
    returning * into v_service;
  end if;
  return v_service;
end;
$$;
grant execute on function public.upsert_provider_service(uuid, text, text, numeric, integer, boolean) to authenticated;

alter table if exists public.bookings
  add column if not exists meeting_url text,
  add column if not exists notes text,
  add column if not exists duration_minutes integer default 60,
  add column if not exists service_id uuid references public.coach_services(id),
  add column if not exists payment_reference text,
  add column if not exists payment_status text,
  add column if not exists paid_at timestamptz;

create or replace function public.approve_booking_completion(p_booking_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare v_booking public.bookings%rowtype;
declare v_wallet_id uuid;
declare v_amount numeric := 0;
declare v_provider_user_id uuid;
begin
  select * into v_booking from public.bookings where id = p_booking_id and learner_id = auth.uid();
  if not found then raise exception 'Booking not found for this learner'; end if;

  select user_id into v_provider_user_id from public.coach_profiles where id = v_booking.coach_id limit 1;

  select coalesce(cs.price, 0) into v_amount
  from public.coach_services cs
  where cs.id = v_booking.service_id;

  update public.bookings set status = 'learner_approved', updated_at = now() where id = p_booking_id;

  if v_provider_user_id is not null and coalesce(v_amount, 0) > 0 then
    insert into public.wallets (user_id, currency, balance, pending_balance, available_balance)
    values (v_provider_user_id, 'USD', 0, 0, 0)
    on conflict (user_id) do nothing;

    select id into v_wallet_id from public.wallets where user_id = v_provider_user_id limit 1;

    update public.wallets
    set pending_balance = coalesce(pending_balance, 0) + v_amount,
        updated_at = now()
    where id = v_wallet_id;

    insert into public.wallet_pending_releases (wallet_id, source_type, source_id, amount, release_at)
    values (v_wallet_id, 'booking', p_booking_id, v_amount, now() + interval '8 days');

    insert into public.wallet_ledger (wallet_id, amount, type, description)
    values (v_wallet_id, v_amount, 'credit', 'Booking approved by learner. Funds are pending for 8 days.');
  end if;

  return jsonb_build_object('ok', true, 'booking_id', p_booking_id, 'amount', v_amount);
end;
$$;
grant execute on function public.approve_booking_completion(uuid) to authenticated;
