-- COURSEVIA dashboard corrections: bank directory + provider services + safe RLS/RPC helpers

create extension if not exists pgcrypto;

-- 1) Bank accounts alignment -------------------------------------------------
alter table if exists public.bank_accounts
  add column if not exists country_code text,
  add column if not exists bank_code text,
  add column if not exists is_default boolean default false;

create table if not exists public.bank_directory (
  id uuid primary key default gen_random_uuid(),
  country text not null,
  country_code text,
  bank_name text not null,
  bank_code text,
  swift_code text,
  provider text default 'manual',
  metadata jsonb default '{}'::jsonb,
  supports_payout boolean not null default true,
  supports_account_resolve boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table if exists public.bank_directory
  add column if not exists provider text default 'manual',
  add column if not exists metadata jsonb default '{}'::jsonb,
  add column if not exists supports_payout boolean not null default true,
  add column if not exists supports_account_resolve boolean not null default false;

create unique index if not exists bank_directory_country_bank_unique
  on public.bank_directory (coalesce(country_code, ''), lower(bank_name));

alter table public.bank_directory enable row level security;

drop policy if exists "Authenticated users can read bank directory" on public.bank_directory;
create policy "Authenticated users can read bank directory"
  on public.bank_directory
  for select
  to authenticated
  using (is_active = true);

drop policy if exists "Admins can manage bank directory" on public.bank_directory;
create policy "Admins can manage bank directory"
  on public.bank_directory
  for all
  to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

drop policy if exists "Users can manage own bank accounts" on public.bank_accounts;
create policy "Users can manage own bank accounts"
  on public.bank_accounts
  for all
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create or replace function public.search_bank_directory(
  p_country_code text default null,
  p_query text default null,
  p_limit integer default 100
)
returns table (
  id uuid,
  country text,
  country_code text,
  bank_name text,
  bank_code text,
  swift_code text
)
language sql
security definer
set search_path = public
stable
as $$
  select bd.id, bd.country, bd.country_code, bd.bank_name, bd.bank_code, bd.swift_code
  from public.bank_directory bd
  where bd.is_active = true
    and (
      p_country_code is null
      or trim(p_country_code) = ''
      or upper(coalesce(bd.country_code, '')) = upper(trim(p_country_code))
    )
    and (
      p_query is null
      or trim(p_query) = ''
      or bd.bank_name ilike '%' || trim(p_query) || '%'
      or coalesce(bd.swift_code, '') ilike '%' || trim(p_query) || '%'
      or coalesce(bd.bank_code, '') ilike '%' || trim(p_query) || '%'
    )
  order by bd.country, bd.bank_name
  limit greatest(1, least(coalesce(p_limit, 100), 250));
$$;

grant execute on function public.search_bank_directory(text, text, integer) to authenticated;

create or replace function public.save_bank_directory_entry(
  p_country_code text,
  p_country text,
  p_bank_name text,
  p_swift_code text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
begin
  if trim(coalesce(p_bank_name, '')) = '' then
    raise exception 'Bank name is required';
  end if;

  insert into public.bank_directory (country, country_code, bank_name, swift_code, provider, metadata, supports_payout, supports_account_resolve)
  values (
    coalesce(nullif(trim(p_country), ''), coalesce(nullif(trim(p_country_code), ''), 'Unknown')),
    nullif(trim(p_country_code), ''),
    trim(p_bank_name),
    nullif(trim(p_swift_code), ''),
    'manual',
    '{}'::jsonb,
    true,
    false
  )
  on conflict (coalesce(country_code, ''), lower(bank_name)) do update
    set swift_code = coalesce(excluded.swift_code, public.bank_directory.swift_code),
        provider = coalesce(public.bank_directory.provider, excluded.provider, 'manual'),
        metadata = coalesce(public.bank_directory.metadata, excluded.metadata, '{}'::jsonb),
        supports_payout = true,
        supports_account_resolve = coalesce(public.bank_directory.supports_account_resolve, false),
        updated_at = now(),
        is_active = true
  returning id into v_id;

  return v_id;
end;
$$;

grant execute on function public.save_bank_directory_entry(text, text, text, text) to authenticated;

-- 2) Provider profile + services alignment ----------------------------------
create unique index if not exists coach_profiles_user_id_unique_idx
  on public.coach_profiles(user_id);

alter table public.coach_services
  alter column duration_minutes set default 60;

update public.coach_services
set is_active = true
where is_active is null;

alter table public.coach_services
  alter column is_active set default true;

alter table public.coach_services enable row level security;

drop policy if exists "Services viewable by everyone" on public.coach_services;
create policy "Services viewable by everyone"
  on public.coach_services
  for select
  using (coalesce(is_active, true) = true or exists (
    select 1 from public.coach_profiles cp
    where cp.id = coach_id and cp.user_id = auth.uid()
  ) or public.has_role(auth.uid(), 'admin'));

drop policy if exists "Coaches can manage own services" on public.coach_services;
create policy "Coaches can manage own services"
  on public.coach_services
  for all
  to authenticated
  using (
    exists (
      select 1 from public.coach_profiles cp
      where cp.id = coach_id and cp.user_id = auth.uid()
    ) or public.has_role(auth.uid(), 'admin')
  )
  with check (
    exists (
      select 1 from public.coach_profiles cp
      where cp.id = coach_id and cp.user_id = auth.uid()
    ) or public.has_role(auth.uid(), 'admin')
  );

create or replace function public.get_or_create_provider_profile()
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_profile_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  select id into v_profile_id
  from public.coach_profiles
  where user_id = auth.uid()
  limit 1;

  if v_profile_id is null then
    insert into public.coach_profiles (user_id, hourly_rate, rating, total_reviews, total_students, is_verified, is_active)
    values (auth.uid(), 0, 0, 0, 0, false, true)
    on conflict (user_id) do update set updated_at = now()
    returning id into v_profile_id;
  end if;

  return v_profile_id;
end;
$$;

grant execute on function public.get_or_create_provider_profile() to authenticated;

create or replace function public.upsert_provider_service(
  p_service_id uuid default null,
  p_title text default null,
  p_description text default null,
  p_price numeric default 0,
  p_duration_minutes integer default 60,
  p_is_active boolean default true
)
returns public.coach_services
language plpgsql
security definer
set search_path = public
as $$
declare
  v_profile_id uuid;
  v_service public.coach_services;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  if trim(coalesce(p_title, '')) = '' then
    raise exception 'Service title is required';
  end if;

  v_profile_id := public.get_or_create_provider_profile();

  if p_service_id is null then
    insert into public.coach_services (coach_id, title, description, price, duration_minutes, is_active)
    values (
      v_profile_id,
      trim(p_title),
      nullif(trim(p_description), ''),
      greatest(coalesce(p_price, 0), 0),
      greatest(coalesce(p_duration_minutes, 60), 15),
      coalesce(p_is_active, true)
    )
    returning * into v_service;
  else
    update public.coach_services
    set title = trim(p_title),
        description = nullif(trim(p_description), ''),
        price = greatest(coalesce(p_price, 0), 0),
        duration_minutes = greatest(coalesce(p_duration_minutes, 60), 15),
        is_active = coalesce(p_is_active, true)
    where id = p_service_id
      and coach_id = v_profile_id
    returning * into v_service;

    if v_service.id is null then
      raise exception 'Service not found or not owned by current user';
    end if;
  end if;

  return v_service;
end;
$$;

grant execute on function public.upsert_provider_service(uuid, text, text, numeric, integer, boolean) to authenticated;

-- 3) Booking safety helpers --------------------------------------------------
alter table if exists public.bookings
  add column if not exists meeting_url text,
  add column if not exists notes text,
  add column if not exists duration_minutes integer default 60,
  add column if not exists service_id uuid references public.coach_services(id);

create or replace function public.approve_booking_completion(p_booking_id uuid)
returns public.bookings
language plpgsql
security definer
set search_path = public
as $$
declare
  v_booking public.bookings;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;

  update public.bookings b
  set status = 'completed',
      updated_at = now()
  where b.id = p_booking_id
    and (
      b.learner_id = auth.uid()
      or exists (
        select 1 from public.coach_profiles cp
        where cp.id = b.coach_id and cp.user_id = auth.uid()
      )
      or public.has_role(auth.uid(), 'admin')
    )
  returning * into v_booking;

  if v_booking.id is null then
    raise exception 'Booking not found or access denied';
  end if;

  return v_booking;
end;
$$;

grant execute on function public.approve_booking_completion(uuid) to authenticated;
