import express from "express";
import dotenv from "dotenv";
import crypto from "crypto";
import { createClient } from "@supabase/supabase-js";

dotenv.config({ path: "backend/.env" });
dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 5000);

const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY || "";
const PAYSTACK_BASE_URL = "https://api.paystack.co";
const APP_URL = (process.env.APP_URL || "http://localhost:8080").replace(/\/$/, "");
const SUPABASE_URL = process.env.SUPABASE_URL || "";
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || "";
const DEFAULT_CURRENCY = (process.env.PAYSTACK_CURRENCY || "USD").toUpperCase();
const MONTHLY_PLAN_KEY = process.env.PAYSTACK_MONTHLY_PLAN_KEY || "learner_monthly";
const MONTHLY_PLAN_NAME = process.env.PAYSTACK_MONTHLY_PLAN_NAME || "Learner Membership Monthly";
const MONTHLY_PLAN_INTERVAL = (process.env.PAYSTACK_MONTHLY_PLAN_INTERVAL || "monthly").toLowerCase();
const MONTHLY_PLAN_AMOUNT = Number(process.env.PAYSTACK_MONTHLY_PLAN_AMOUNT || 1000);
const YEARLY_PLAN_KEY = process.env.PAYSTACK_YEARLY_PLAN_KEY || "learner_yearly";
const YEARLY_PLAN_NAME = process.env.PAYSTACK_YEARLY_PLAN_NAME || "Learner Membership Yearly";
const YEARLY_PLAN_INTERVAL = (process.env.PAYSTACK_YEARLY_PLAN_INTERVAL || "annually").toLowerCase();
const YEARLY_PLAN_AMOUNT = Number(process.env.PAYSTACK_YEARLY_PLAN_AMOUNT || 12000);

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { autoRefreshToken: false, persistSession: false },
});

const jsonParser = express.json();
const webhookRawParser = express.raw({ type: "application/json" });

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", process.env.CORS_ORIGIN || "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  res.header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
  if (req.method === "OPTIONS") {
    return res.sendStatus(204);
  }
  next();
});

const paystackRequest = async (path, options = {}) => {
  const response = await fetch(`${PAYSTACK_BASE_URL}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });

  const data = await response.json();
  if (!response.ok || data?.status === false) {
    throw new Error(data?.message || `Paystack request failed for ${path}`);
  }
  return data.data;
};


const PAYOUT_PROVIDER_BY_COUNTRY = {
  NG: { provider: "paystack", rails: ["local_bank", "swift"], supportsResolve: true, verification: "otp" },
  GH: { provider: "paystack", rails: ["local_bank", "swift"], supportsResolve: true, verification: "otp" },
  ZA: { provider: "paystack", rails: ["local_bank", "swift"], supportsResolve: true, verification: "otp" },
  KE: { provider: "paystack", rails: ["local_bank", "swift"], supportsResolve: false, verification: "otp" },
  US: { provider: "manual_swift", rails: ["swift", "iban"], supportsResolve: false, verification: "manual" },
  GB: { provider: "manual_swift", rails: ["swift", "iban"], supportsResolve: false, verification: "manual" },
  CA: { provider: "manual_swift", rails: ["swift"], supportsResolve: false, verification: "manual" },
  AU: { provider: "manual_swift", rails: ["swift"], supportsResolve: false, verification: "manual" },
};

const getPayoutCapability = (countryCode, currency = null) => {
  const code = String(countryCode || "").trim().toUpperCase();
  const direct = PAYOUT_PROVIDER_BY_COUNTRY[code];
  if (direct) {
    return {
      country_code: code,
      currency: String(currency || "").trim().toUpperCase() || null,
      provider: direct.provider,
      rails: direct.rails,
      supports_account_resolve: direct.supportsResolve,
      verification_mode: direct.verification,
      supported: true,
      note: direct.provider === "manual_swift"
        ? "This country uses verified manual beneficiary details instead of instant account-name lookup."
        : "This country supports provider-backed beneficiary verification.",
    };
  }

  return {
    country_code: code,
    currency: String(currency || "").trim().toUpperCase() || null,
    provider: "manual_swift",
    rails: ["swift"],
    supports_account_resolve: false,
    verification_mode: "manual",
    supported: true,
    note: "No instant local-bank resolver is configured for this country yet. Users can still save verified SWIFT/manual payout details.",
  };
};

const randomOtp = () => String(Math.floor(100000 + Math.random() * 900000));

const hashCode = (value) => crypto.createHash("sha256").update(String(value)).digest("hex");

const normalizeEmail = (email) => String(email || "").trim().toLowerCase();

const getUserEmail = async (userId) => {
  if (!userId) return null;
  try {
    const { data, error } = await supabase.auth.admin.getUserById(userId);
    if (error) throw error;
    return data?.user?.email || null;
  } catch (error) {
    console.error("Could not look up user email", error?.message || error);
    return null;
  }
};

const sendVerificationCode = async ({ userId, email, code, countryCode, bankName, accountNumber }) => {
  const targetEmail = normalizeEmail(email) || await getUserEmail(userId);
  if (!targetEmail) {
    return { delivered: false, reason: "No email found for verification delivery" };
  }

  try {
    await supabase.from("broadcasts").insert({
      title: "Coursevia payout verification code",
      message: `Your Coursevia payout verification code is ${code}. Country: ${countryCode}. Bank: ${bankName}. Account: ${accountNumber}. This code expires in 15 minutes.`,
      target_type: "user",
      target_id: userId,
      status: "queued",
      metadata: { category: "payout_verification", email: targetEmail },
    });
    return { delivered: true, channel: "broadcasts" };
  } catch (error) {
    console.error("Verification delivery fallback", error?.message || error);
    return { delivered: false, reason: "Broadcast queue is unavailable. The code is still generated for testing." };
  }
};

const fetchBanksFromDirectory = async ({ countryCode, provider, query }) => {
  let db = supabase
    .from("bank_directory")
    .select("id, bank_name, bank_code, country_code, provider, metadata, swift_code")
    .eq("is_active", true);
  if (countryCode) db = db.eq("country_code", String(countryCode).toUpperCase());
  if (query) db = db.ilike("bank_name", `%${query}%`);

  const { data, error } = await db.order("bank_name", { ascending: true }).limit(100);
  if (error) throw new Error(error.message);
  return (data || []).map((row) => ({
    ...row,
    provider: row.provider || provider || "manual",
    metadata: row.metadata || {},
  }));
};

const fetchPaystackBanks = async (countryCode) => {
  const supported = ["NG", "GH", "KE", "ZA"].includes(String(countryCode || "").toUpperCase());
  if (!supported || !PAYSTACK_SECRET_KEY) return [];
  const data = await paystackRequest(`/bank?country=${encodeURIComponent(countryCode.toLowerCase())}&use_cursor=false&perPage=100`);
  const rows = Array.isArray(data) ? data : [];

  for (const row of rows) {
    const bankCode = String(row.code || row.id || "");
    const bankName = String(row.name || "").trim();
    if (!bankCode || !bankName) continue;
    try {
      await supabase.from("bank_directory").upsert({
        provider: "paystack",
        country_code: String(countryCode).toUpperCase(),
        bank_code: bankCode,
        bank_name: bankName,
        supports_payout: true,
        supports_account_resolve: true,
        is_active: true,
        metadata: row,
      }, { onConflict: "provider,country_code,bank_code" });
    } catch (error) {
      console.error("Could not sync bank_directory row", error?.message || error);
    }
  }

  return rows.map((row) => ({
    id: String(row.id || row.code || row.name),
    bank_name: row.name,
    bank_code: String(row.code || ""),
    country_code: String(countryCode).toUpperCase(),
    provider: "paystack",
    metadata: row,
  }));
};

const resolveBeneficiary = async ({ countryCode, bankCode, accountNumber, accountName }) => {
  const capability = getPayoutCapability(countryCode);
  if (capability.provider === "paystack" && capability.supports_account_resolve && bankCode && accountNumber) {
    try {
      const result = await paystackRequest(`/bank/resolve?account_number=${encodeURIComponent(accountNumber)}&bank_code=${encodeURIComponent(bankCode)}`);
      return {
        resolved: true,
        provider: capability.provider,
        verification_mode: capability.verification_mode,
        account_name: result.account_name || accountName || "",
        account_number: result.account_number || accountNumber,
        bank_id: result.bank_id || null,
        note: "Account details were confirmed by the payout provider.",
      };
    } catch (error) {
      throw new Error(error.message || "Could not resolve this account with the payout provider.");
    }
  }

  if (!accountName) {
    throw new Error("Account name is required for countries without instant account lookup.");
  }

  return {
    resolved: true,
    provider: capability.provider,
    verification_mode: capability.verification_mode,
    account_name: accountName,
    account_number: accountNumber,
    bank_id: null,
    note: capability.note,
  };
};

const createTransferRecipientIfPossible = async ({ type, name, accountNumber, bankCode, currency }) => {
  if (!PAYSTACK_SECRET_KEY || !bankCode || !accountNumber || !name) return null;
  try {
    const data = await paystackRequest("/transferrecipient", {
      method: "POST",
      body: JSON.stringify({
        type: type || "nuban",
        name,
        account_number: accountNumber,
        bank_code: bankCode,
        currency: String(currency || DEFAULT_CURRENCY).toUpperCase(),
      }),
    });
    return data?.recipient_code || null;
  } catch (error) {
    console.error("recipient creation skipped", error?.message || error);
    return null;
  }
};

const addMonths = (date, months) => {
  const next = new Date(date);
  next.setMonth(next.getMonth() + months);
  return next;
};

const intervalToMonths = (interval) => {
  switch (String(interval || "").toLowerCase()) {
    case "annually":
      return 12;
    case "biannually":
      return 6;
    case "quarterly":
      return 3;
    default:
      return 1;
  }
};

const computePeriodEnd = (startsAt, interval) => {
  const start = new Date(startsAt);
  return addMonths(start, intervalToMonths(interval)).toISOString();
};

const ensureBillingPlan = async ({ planKey, planName, interval, amount }) => {
  const { data: existing, error } = await supabase
    .from("billing_plans")
    .select("id, provider_plan_code, amount, interval, currency, name")
    .eq("plan_key", planKey)
    .maybeSingle();

  if (error) throw new Error(error.message);
  if (existing?.provider_plan_code) return existing;

  const paystackPlan = await paystackRequest("/plan", {
    method: "POST",
    body: JSON.stringify({
      name: planName,
      amount,
      interval,
      description: `${planName} recurring membership`,
      send_invoices: true,
      send_sms: false,
      currency: DEFAULT_CURRENCY,
    }),
  });

  const { data: inserted, error: insertError } = await supabase
    .from("billing_plans")
    .upsert({
      plan_key: planKey,
      name: planName,
      amount: amount / 100,
      interval,
      currency: DEFAULT_CURRENCY,
      provider: "paystack",
      provider_plan_code: paystackPlan.plan_code,
      active: true,
      metadata: { paystack_plan_id: paystackPlan.id, raw: paystackPlan },
    }, { onConflict: "plan_key" })
    .select("id, provider_plan_code, amount, interval, currency, name")
    .single();

  if (insertError) throw new Error(insertError.message);
  return inserted;
};

const getPlanConfig = (plan = "monthly") => {
  if (String(plan).toLowerCase() === "yearly") {
    return {
      key: YEARLY_PLAN_KEY,
      name: YEARLY_PLAN_NAME,
      interval: YEARLY_PLAN_INTERVAL,
      amount: YEARLY_PLAN_AMOUNT,
    };
  }

  return {
    key: MONTHLY_PLAN_KEY,
    name: MONTHLY_PLAN_NAME,
    interval: MONTHLY_PLAN_INTERVAL,
    amount: MONTHLY_PLAN_AMOUNT,
  };
};

const safeRpcReleaseProviderEarning = async ({ providerId, buyerId, sourceType, sourceId, grossAmount, platformFee, reference, metadata }) => {
  if (!providerId || !grossAmount) return;
  try {
    await supabase.rpc("release_provider_earning", {
      _provider_id: providerId,
      _buyer_id: buyerId,
      _source_type: sourceType,
      _source_id: sourceId,
      _gross_amount: Number(grossAmount),
      _platform_fee: Number(platformFee || 0),
      _currency: "USD",
      _provider_reference: reference,
      _metadata: metadata || {},
    });
  } catch (error) {
    console.error("release_provider_earning skipped:", error?.message || error);
  }
};

const storePayment = async (paymentRow) => {
  const { error } = await supabase.from("payments").upsert(paymentRow, { onConflict: "reference" });
  if (error) throw new Error(error.message);
};

const grantContentAccess = async ({ userId, contentId, paymentType }) => {
  if (!contentId || !userId || (paymentType !== "course" && paymentType !== "video")) return;
  try {
    await supabase.from("content_access").upsert({
      user_id: userId,
      content_id: contentId,
      access_type: paymentType,
      source: "purchase",
      unlocked_at: new Date().toISOString(),
    }, { onConflict: "user_id,content_id" });
  } catch (error) {
    console.error("content access grant skipped:", error?.message || error);
  }
};

const finalizeBookingPayment = async ({ bookingId, reference, amount, userId, transaction }) => {
  if (!bookingId) return;

  const { data: booking } = await supabase
    .from("bookings")
    .select("id, coach_id, learner_id, service_id, meeting_url")
    .eq("id", bookingId)
    .maybeSingle();

  let providerUserId = null;
  if (booking?.coach_id) {
    const { data: providerProfile } = await supabase
      .from("coach_profiles")
      .select("user_id")
      .eq("id", booking.coach_id)
      .maybeSingle();
    providerUserId = providerProfile?.user_id || null;
  }

  const meetingUrl = booking?.meeting_url || `https://meet.jit.si/coursevia-${bookingId}`;

  const bookingUpdate = {
    status: "confirmed",
    meeting_url: meetingUrl,
    updated_at: new Date().toISOString(),
  };

  const { error: bookingUpdateError } = await supabase
    .from("bookings")
    .update(bookingUpdate)
    .eq("id", bookingId);

  if (bookingUpdateError) {
    throw new Error(bookingUpdateError.message);
  }

  await safeRpcReleaseProviderEarning({
    providerId: providerUserId,
    buyerId: booking?.learner_id || userId,
    sourceType: "booking",
    sourceId: bookingId,
    grossAmount: amount,
    platformFee: Number(amount) * 0.05,
    reference,
    metadata: { booking_id: bookingId, service_id: booking?.service_id || null },
  });
};

const finalizeSubscription = async ({ transaction, metadata, eventName = "charge.success" }) => {
  const userId = metadata.user_id || metadata.userId;
  if (!userId) throw new Error("Missing user_id in payment metadata");

  const planChoice = String(metadata.plan || "monthly").toLowerCase() === "yearly" ? "yearly" : "monthly";
  const planConfig = getPlanConfig(planChoice);
  const startedAt = transaction?.paid_at || transaction?.created_at || new Date().toISOString();
  const expiresAt = computePeriodEnd(startedAt, planConfig.interval);
  const amount = Number(transaction?.amount || 0) / 100;
  const reference = transaction?.reference || metadata.reference || null;
  const customerCode = transaction?.customer?.customer_code || metadata.customer_code || null;
  const subscriptionCode = transaction?.subscription?.subscription_code || metadata.subscription_code || null;
  const emailToken = transaction?.subscription?.email_token || metadata.email_token || null;
  const planCode = transaction?.plan || metadata.plan_code || null;

  await storePayment({
    user_id: userId,
    payer_id: userId,
    reference,
    amount,
    currency: String(transaction?.currency || DEFAULT_CURRENCY).toUpperCase(),
    status: "completed",
    provider: "paystack",
    payment_type: "subscription",
    payment_method: transaction?.channel || "card",
    provider_customer_code: customerCode,
    provider_plan_code: planCode,
    provider_subscription_code: subscriptionCode,
    provider_email_token: emailToken,
    metadata: { event: eventName, raw: transaction },
  });

  const { error } = await supabase.from("subscriptions").upsert({
    user_id: userId,
    plan: planChoice,
    amount,
    billing_cycle: planConfig.interval,
    status: "active",
    starts_at: startedAt,
    ends_at: expiresAt,
    started_at: startedAt,
    expires_at: expiresAt,
    payment_provider: "paystack",
    paystack_customer_code: customerCode,
    paystack_plan_code: planCode,
    paystack_subscription_code: subscriptionCode,
    paystack_email_token: emailToken,
    last_payment_reference: reference,
    cancel_at_period_end: false,
    metadata: { event: eventName, raw: transaction },
  }, { onConflict: "user_id" });

  if (error) throw new Error(error.message);

  return { purpose: "subscription", reference, redirectTo: "/dashboard/subscription", message: `Your ${planChoice} membership is now active.` };
};

const finalizeOneTimePayment = async ({ transaction, metadata }) => {
  const userId = metadata.user_id || metadata.userId;
  const purpose = metadata.purpose;
  const contentId = metadata.content_id || null;
  const reference = transaction?.reference || metadata.reference || null;
  const amount = Number(transaction?.amount || 0) / 100;

  if (!userId || !purpose) throw new Error("Missing payment metadata");

  await storePayment({
    user_id: userId,
    payer_id: userId,
    reference,
    amount,
    currency: String(transaction?.currency || DEFAULT_CURRENCY).toUpperCase(),
    status: "completed",
    provider: "paystack",
    payment_type: purpose,
    payment_method: transaction?.channel || "card",
    reference_id: contentId,
    metadata: { purpose, content_id: contentId, raw: transaction },
  });

  if (purpose === "course" || purpose === "video") {
    await grantContentAccess({ userId, contentId, paymentType: purpose });
    return {
      purpose,
      reference,
      redirectTo: purpose === "course" ? "/dashboard/courses" : "/dashboard/videos",
      message: `${purpose === "course" ? "Course" : "Video"} payment confirmed successfully.`,
    };
  }

  if (purpose === "booking") {
    await finalizeBookingPayment({ bookingId: contentId, reference, amount, userId, transaction });
    return {
      purpose,
      reference,
      redirectTo: "/dashboard/bookings",
      message: "Booking payment confirmed. Your session details are now available.",
    };
  }

  return { purpose, reference, redirectTo: "/dashboard/payments", message: "Payment confirmed successfully." };
};

const verifyAndApplyTransaction = async (reference, eventName = "verify") => {
  const transaction = await paystackRequest(`/transaction/verify/${encodeURIComponent(reference)}`);
  if (transaction?.status !== "success") {
    throw new Error(`Payment status is ${transaction?.status || "unknown"}`);
  }

  const metadata = transaction?.metadata || {};
  const purpose = metadata?.purpose;

  if (purpose === "learner_subscription") {
    return finalizeSubscription({ transaction, metadata, eventName });
  }

  return finalizeOneTimePayment({ transaction, metadata });
};

app.get("/", (_req, res) => {
  res.json({ ok: true, service: "coursevia-payments" });
});

const initializeCheckout = async ({ email, userId, type, amount, contentId, contentTitle, plan }) => {
  if (!email || !userId || !type) {
    throw new Error("email, user_id, and type are required");
  }

  let checkoutAmount = Number(amount || 0);
  let paystackPlanCode = null;
  let purpose = type;

  if (type === "subscription") {
    const planConfig = getPlanConfig(plan);
    const billingPlan = await ensureBillingPlan({
      planKey: planConfig.key,
      planName: planConfig.name,
      interval: planConfig.interval,
      amount: planConfig.amount,
    });
    checkoutAmount = Math.round(Number(billingPlan.amount || planConfig.amount / 100) * 100);
    paystackPlanCode = billingPlan.provider_plan_code;
    purpose = "learner_subscription";
  }

  if ((type === "course" || type === "video" || type === "booking") && checkoutAmount <= 0) {
    throw new Error("A valid payment amount is required");
  }

  const reference = `${type}_${Date.now()}_${crypto.randomBytes(6).toString("hex")}`;
  const initialized = await paystackRequest("/transaction/initialize", {
    method: "POST",
    body: JSON.stringify({
      email,
      amount: checkoutAmount,
      currency: DEFAULT_CURRENCY,
      ...(paystackPlanCode ? { plan: paystackPlanCode } : {}),
      reference,
      callback_url: `${APP_URL}/subscription/callback`,
      metadata: {
        user_id: userId,
        purpose,
        plan: plan || "monthly",
        content_id: contentId,
        content_title: contentTitle,
        reference,
        ...(paystackPlanCode ? { plan_code: paystackPlanCode } : {}),
      },
    }),
  });

  return {
    authorization_url: initialized.authorization_url,
    access_code: initialized.access_code,
    reference,
  };
};

app.post("/api/checkout/initialize", jsonParser, async (req, res) => {
  try {
    const result = await initializeCheckout({
      email: req.body?.email,
      userId: req.body?.user_id,
      type: req.body?.type,
      amount: req.body?.amount,
      contentId: req.body?.content_id,
      contentTitle: req.body?.content_title,
      plan: req.body?.plan,
    });
    return res.json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to initialize checkout" });
  }
});

app.get("/api/checkout/verify", async (req, res) => {
  try {
    const reference = String(req.query.reference || "").trim();
    if (!reference) return res.status(400).json({ error: "reference is required" });
    const result = await verifyAndApplyTransaction(reference, "verify");
    return res.json({ success: true, ...result });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to verify payment" });
  }
});

app.post("/api/subscriptions/initialize", jsonParser, async (req, res) => {
  try {
    const result = await initializeCheckout({
      email: req.body?.email,
      userId: req.body?.user_id,
      type: "subscription",
      plan: req.body?.plan || "monthly",
    });
    return res.json(result);
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to initialize subscription" });
  }
});

app.get("/api/subscriptions/verify", async (req, res) => {
  try {
    const reference = String(req.query.reference || "").trim();
    if (!reference) return res.status(400).json({ error: "reference is required" });
    const result = await verifyAndApplyTransaction(reference, "verify");
    return res.json({ success: true, ...result });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to verify subscription" });
  }
});

app.post("/api/subscriptions/cancel", jsonParser, async (req, res) => {
  try {
    const { user_id: userId } = req.body || {};
    if (!userId) return res.status(400).json({ error: "user_id is required" });

    const { data: subscription, error } = await supabase
      .from("subscriptions")
      .select("paystack_subscription_code, paystack_email_token")
      .eq("user_id", userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!subscription?.paystack_subscription_code || !subscription?.paystack_email_token) {
      return res.status(400).json({ error: "No active Paystack subscription found for this user" });
    }

    await paystackRequest("/subscription/disable", {
      method: "POST",
      body: JSON.stringify({ code: subscription.paystack_subscription_code, token: subscription.paystack_email_token }),
    });

    const { error: updateError } = await supabase
      .from("subscriptions")
      .update({ status: "cancelled", cancel_at_period_end: true, metadata: { cancelled_at: new Date().toISOString() } })
      .eq("user_id", userId);
    if (updateError) throw new Error(updateError.message);

    return res.json({ success: true });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to cancel subscription" });
  }
});

app.post("/api/webhooks/paystack", webhookRawParser, async (req, res) => {
  try {
    const signature = req.headers["x-paystack-signature"];
    const expected = crypto.createHmac("sha512", PAYSTACK_SECRET_KEY).update(req.body).digest("hex");

    if (!signature || signature !== expected) {
      return res.status(401).json({ error: "Invalid webhook signature" });
    }

    const event = JSON.parse(req.body.toString("utf8"));
    const eventName = String(event?.event || "");

    if (eventName === "charge.success") {
      await verifyAndApplyTransaction(event?.data?.reference, eventName);
    }

    if (eventName === "subscription.disable" || eventName === "subscription.not_renew") {
      const subscriptionCode = event?.data?.subscription_code || null;
      if (subscriptionCode) {
        const { error } = await supabase
          .from("subscriptions")
          .update({
            status: eventName === "subscription.disable" ? "cancelled" : "pending_cancellation",
            cancel_at_period_end: true,
            metadata: { webhook_event: eventName, raw: event.data },
          })
          .eq("paystack_subscription_code", subscriptionCode);
        if (error) throw new Error(error.message);
      }
    }

    return res.sendStatus(200);
  } catch (error) {
    console.error("Webhook error", error);
    return res.status(500).json({ error: error.message || "Webhook processing failed" });
  }
});



app.get("/api/payouts/capabilities", async (req, res) => {
  try {
    const countryCode = String(req.query.country || req.query.country_code || "").trim().toUpperCase();
    const currency = String(req.query.currency || "").trim().toUpperCase() || null;
    if (!countryCode) return res.status(400).json({ error: "country is required" });
    return res.json({ success: true, capability: getPayoutCapability(countryCode, currency) });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to load payout capabilities" });
  }
});

app.get("/api/payouts/banks", async (req, res) => {
  try {
    const countryCode = String(req.query.country || req.query.country_code || "").trim().toUpperCase();
    const query = String(req.query.query || "").trim();
    if (!countryCode) return res.status(400).json({ error: "country is required" });
    const capability = getPayoutCapability(countryCode);
    let banks = await fetchBanksFromDirectory({ countryCode, provider: capability.provider, query });
    if (!banks.length && capability.provider === "paystack") {
      banks = await fetchPaystackBanks(countryCode);
      if (query) {
        const q = query.toLowerCase();
        banks = banks.filter((bank) => String(bank.bank_name || "").toLowerCase().includes(q));
      }
    }
    return res.json({ success: true, capability, banks });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to load banks" });
  }
});

app.post("/api/payouts/resolve-beneficiary", jsonParser, async (req, res) => {
  try {
    const { country_code: countryCode, bank_code: bankCode, account_number: accountNumber, account_name: accountName } = req.body || {};
    if (!countryCode || !accountNumber) return res.status(400).json({ error: "country_code and account_number are required" });
    const result = await resolveBeneficiary({ countryCode, bankCode, accountNumber, accountName });
    return res.json({ success: true, ...result });
  } catch (error) {
    return res.status(400).json({ error: error.message || "Could not resolve beneficiary" });
  }
});

app.get("/api/payouts/accounts", async (req, res) => {
  try {
    const userId = String(req.query.user_id || "").trim();
    if (!userId) return res.status(400).json({ error: "user_id is required" });
    const { data, error } = await supabase
      .from("user_bank_accounts")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return res.json({ success: true, accounts: data || [] });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to load payout accounts" });
  }
});

app.post("/api/payouts/send-verification", jsonParser, async (req, res) => {
  try {
    const { user_id: userId, email, country_code: countryCode, currency, bank_code: bankCode, bank_name: bankName, account_number: accountNumber, account_name: accountName, swift_code: swiftCode, iban, payout_method_type } = req.body || {};
    if (!userId || !countryCode || !bankName || !accountNumber) return res.status(400).json({ error: "user_id, country_code, bank_name, and account_number are required" });

    const capability = getPayoutCapability(countryCode, currency);
    const resolved = await resolveBeneficiary({ countryCode, bankCode, accountNumber, accountName });
    const verificationCode = capability.verification_mode === "manual" ? null : randomOtp();
    const codeHash = verificationCode ? hashCode(verificationCode) : null;
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();

    const { data, error } = await supabase
      .from("user_bank_accounts")
      .insert({
        user_id: userId,
        provider: capability.provider,
        country_code: String(countryCode).toUpperCase(),
        bank_code: bankCode || null,
        bank_name: bankName,
        account_number: accountNumber,
        account_name: resolved.account_name || accountName || null,
        recipient_code: null,
        verification_method: capability.verification_mode === "manual" ? "manual" : "otp",
        verification_status: capability.verification_mode === "manual" ? "verified" : "initiated",
        verification_code: codeHash,
        is_default: false,
        is_active: true,
        metadata: {
          swift_code: swiftCode || null,
          iban: iban || null,
          payout_method_type: payout_method_type || capability.rails[0] || "swift",
          verification_expires_at: expiresAt,
          delivery_email: normalizeEmail(email),
          capability,
          resolved_note: resolved.note || null,
        },
      })
      .select("*")
      .single();

    if (error) throw error;

    let delivery = { delivered: false, reason: "manual verification account" };
    if (verificationCode) {
      delivery = await sendVerificationCode({ userId, email, code: verificationCode, countryCode, bankName, accountNumber });
    }

    return res.json({
      success: true,
      account: data,
      verification_required: Boolean(verificationCode),
      verification_mode: capability.verification_mode,
      delivery,
      message: verificationCode
        ? "Verification code created and queued for delivery."
        : "This payout method was saved as verified manual/SWIFT details.",
      ...(process.env.NODE_ENV !== "production" && verificationCode ? { dev_code: verificationCode } : {}),
    });
  } catch (error) {
    return res.status(400).json({ error: error.message || "Failed to start payout verification" });
  }
});

app.post("/api/payouts/verify-beneficiary", jsonParser, async (req, res) => {
  try {
    const { user_id: userId, bank_account_id: bankAccountId, code } = req.body || {};
    if (!userId || !bankAccountId) return res.status(400).json({ error: "user_id and bank_account_id are required" });

    const { data: account, error } = await supabase
      .from("user_bank_accounts")
      .select("*")
      .eq("id", bankAccountId)
      .eq("user_id", userId)
      .maybeSingle();

    if (error) throw error;
    if (!account) return res.status(404).json({ error: "Payout account not found" });

    if (account.verification_status === "verified") {
      return res.json({ success: true, account, message: "Payout account already verified." });
    }

    const expiry = account?.metadata?.verification_expires_at || null;
    if (expiry && new Date(expiry).getTime() < Date.now()) {
      return res.status(400).json({ error: "Verification code has expired. Please request a new one." });
    }

    if (String(account.verification_method || "") === "otp") {
      if (!code) return res.status(400).json({ error: "Verification code is required" });
      const hashed = hashCode(code);
      if (String(account.verification_code || "") !== hashed) {
        return res.status(400).json({ error: "Invalid verification code" });
      }
    }

    const recipientCode = await createTransferRecipientIfPossible({
      type: "nuban",
      name: account.account_name,
      accountNumber: account.account_number,
      bankCode: account.bank_code,
      currency: account?.metadata?.currency || DEFAULT_CURRENCY,
    });

    const { data: updated, error: updateError } = await supabase
      .from("user_bank_accounts")
      .update({
        verification_status: "verified",
        verified_at: new Date().toISOString(),
        recipient_code: recipientCode || account.recipient_code || null,
        verification_code: null,
        is_default: true,
      })
      .eq("id", bankAccountId)
      .eq("user_id", userId)
      .select("*")
      .single();
    if (updateError) throw updateError;

    await supabase
      .from("user_bank_accounts")
      .update({ is_default: false })
      .eq("user_id", userId)
      .neq("id", bankAccountId);

    return res.json({ success: true, account: updated, recipient_code: recipientCode || null });
  } catch (error) {
    return res.status(400).json({ error: error.message || "Failed to verify payout account" });
  }
});


app.delete("/api/payouts/accounts/:id", async (req, res) => {
  try {
    const userId = String(req.query.user_id || "").trim();
    const id = String(req.params.id || "").trim();
    if (!userId || !id) return res.status(400).json({ error: "user_id and account id are required" });
    const { error } = await supabase
      .from("user_bank_accounts")
      .delete()
      .eq("id", id)
      .eq("user_id", userId);
    if (error) throw error;
    return res.json({ success: true });
  } catch (error) {
    return res.status(400).json({ error: error.message || "Failed to delete payout account" });
  }
});

app.post("/api/payouts/withdraw", jsonParser, async (req, res) => {
  try {
    const { user_id: userId, amount, bank_account_id: bankAccountId } = req.body || {};
    if (!userId || !amount || !bankAccountId) return res.status(400).json({ error: "user_id, amount, and bank_account_id are required" });

    const { data: account, error: accountError } = await supabase
      .from("user_bank_accounts")
      .select("*")
      .eq("id", bankAccountId)
      .eq("user_id", userId)
      .maybeSingle();
    if (accountError) throw accountError;
    if (!account) return res.status(404).json({ error: "Verified payout account not found" });
    if (String(account.verification_status || "") !== "verified") {
      return res.status(400).json({ error: "This payout account is not verified yet." });
    }

    let rpcResult = null;
    let rpcError = null;
    try {
      const result = await supabase.rpc("request_withdrawal", { uid: userId, p_amount: Number(amount), p_bank_account_id: bankAccountId });
      rpcResult = result.data;
      rpcError = result.error;
    } catch (error) {
      rpcError = error;
    }

    if (!rpcResult && rpcError) {
      const fallback = await supabase.rpc("self_cashout", { p_amount: Number(amount), p_bank_account_id: bankAccountId });
      if (fallback.error) throw fallback.error;
      rpcResult = fallback.data || null;
    }

    return res.json({
      success: true,
      withdrawal_id: rpcResult || null,
      status: "pending",
      message: "Withdrawal request created. Funds move only from verified payout methods.",
    });
  } catch (error) {
    return res.status(400).json({ error: error.message || "Failed to create withdrawal" });
  }
});

app.get("/api/payouts/withdrawals", async (req, res) => {
  try {
    const userId = String(req.query.user_id || "").trim();
    if (!userId) return res.status(400).json({ error: "user_id is required" });
    const { data, error } = await supabase
      .from("withdrawal_requests")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return res.json({ success: true, withdrawals: data || [] });
  } catch (error) {
    return res.status(500).json({ error: error.message || "Failed to load withdrawals" });
  }
});

app.listen(PORT, () => {
  console.log(`Coursevia payments backend running on port ${PORT}`);
});
