-- Admin bootstrap flow
-- Result:
-- 1) The very first admin can create an admin account directly from /admin-login
-- 2) After the first admin exists, public admin self-signup closes automatically
-- 3) Additional admins should be created by an existing admin from inside the dashboard

CREATE OR REPLACE FUNCTION public.is_admin_bootstrap_open()
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT NOT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE role = 'admin'::public.app_role
  );
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  wants_admin BOOLEAN := COALESCE(NEW.raw_user_meta_data->>'requested_role', '') = 'admin';
  allow_admin_bootstrap BOOLEAN := FALSE;
BEGIN
  allow_admin_bootstrap := wants_admin AND public.is_admin_bootstrap_open();

  INSERT INTO public.profiles (user_id, full_name, avatar_url, onboarding_completed)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
    COALESCE(NEW.raw_user_meta_data->>'avatar_url', ''),
    CASE WHEN allow_admin_bootstrap THEN TRUE ELSE FALSE END
  );

  INSERT INTO public.wallets (user_id) VALUES (NEW.id);

  INSERT INTO public.user_roles (user_id, role)
  VALUES (
    NEW.id,
    CASE
      WHEN allow_admin_bootstrap THEN 'admin'::public.app_role
      ELSE 'learner'::public.app_role
    END
  )
  ON CONFLICT DO NOTHING;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;
