-- Platform upgrade: professional profiles, paid video previews, subscriptions,
-- bank accounts, wallet holding balances, booking meeting links and pricing.

alter table public.profiles add column if not exists full_name text;
alter table public.profiles add column if not exists avatar_url text;
alter table public.profiles add column if not exists onboarding_completed boolean default false;
alter table public.profiles add column if not exists email text;
alter table public.profiles add column if not exists role text default 'learner';
alter table public.profiles add column if not exists bio text;
alter table public.profiles add column if not exists phone text;
alter table public.profiles add column if not exists country text;
alter table public.profiles add column if not exists profession text;
alter table public.profiles add column if not exists experience text;
alter table public.profiles add column if not exists certification text;
alter table public.profiles add column if not exists booking_price numeric default 0;
alter table public.profiles add column if not exists profile_slug text;
alter table public.profiles add column if not exists status text default 'active';

alter table public.categories add column if not exists slug text;

alter table public.videos add column if not exists preview_seconds integer default 5;
alter table public.videos add column if not exists owner_role text default 'creator';
alter table public.videos add column if not exists is_published boolean default true;

alter table public.bookings add column if not exists price numeric default 0;
alter table public.bookings add column if not exists meeting_link text;
alter table public.bookings add column if not exists session_starts_at timestamptz;
alter table public.bookings add column if not exists session_ends_at timestamptz;

alter table public.wallets add column if not exists pending_balance numeric default 0;
alter table public.wallets add column if not exists available_balance numeric default 0;

alter table public.subscriptions add column if not exists amount numeric default 10;
alter table public.subscriptions add column if not exists billing_cycle text default 'monthly';
alter table public.subscriptions add column if not exists expires_at timestamptz;
alter table public.subscriptions add column if not exists started_at timestamptz;

create table if not exists public.bank_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  bank_name text,
  account_name text,
  account_number text,
  swift_code text,
  country text,
  currency text,
  is_default boolean default false,
  created_at timestamptz default now()
);

create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  amount numeric not null default 0,
  platform_fee numeric not null default 0,
  owner_amount numeric not null default 0,
  created_at timestamptz default now()
);

alter table public.bank_accounts enable row level security;
alter table public.purchases enable row level security;

do $$
begin
  if not exists (
    select 1 from pg_policies where schemaname = 'public' and tablename = 'bank_accounts' and policyname = 'Users can view own bank accounts'
  ) then
    create policy "Users can view own bank accounts"
    on public.bank_accounts for select using (auth.uid() = user_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname = 'public' and tablename = 'bank_accounts' and policyname = 'Users can insert own bank accounts'
  ) then
    create policy "Users can insert own bank accounts"
    on public.bank_accounts for insert with check (auth.uid() = user_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname = 'public' and tablename = 'bank_accounts' and policyname = 'Users can update own bank accounts'
  ) then
    create policy "Users can update own bank accounts"
    on public.bank_accounts for update using (auth.uid() = user_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname = 'public' and tablename = 'purchases' and policyname = 'Users can view own purchases'
  ) then
    create policy "Users can view own purchases"
    on public.purchases for select using (auth.uid() = user_id);
  end if;

  if not exists (
    select 1 from pg_policies where schemaname = 'public' and tablename = 'purchases' and policyname = 'Users can insert own purchases'
  ) then
    create policy "Users can insert own purchases"
    on public.purchases for insert with check (auth.uid() = user_id);
  end if;
end $$;
