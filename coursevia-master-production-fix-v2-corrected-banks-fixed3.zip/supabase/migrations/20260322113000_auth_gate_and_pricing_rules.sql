create or replace function public.check_user_exists_by_email(user_email text)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from auth.users
    where lower(email) = lower(user_email)
  );
$$;
