-- Unified content system
create table if not exists public.content_items (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  owner_role text,
  title text not null,
  slug text unique,
  description text,
  content_type text not null check (content_type in ('single_video','episode_series','course')),
  thumbnail_url text,
  price numeric not null default 0,
  category_id uuid null,
  preview_seconds integer not null default 5,
  is_published boolean not null default true,
  created_at timestamp with time zone not null default now(),
  updated_at timestamp with time zone not null default now()
);

create table if not exists public.content_episodes (
  id uuid primary key default gen_random_uuid(),
  content_id uuid not null references public.content_items(id) on delete cascade,
  title text not null,
  description text,
  video_url text not null,
  episode_number integer not null default 1,
  duration_seconds integer not null default 0,
  is_preview boolean not null default false,
  created_at timestamp with time zone not null default now()
);

create table if not exists public.content_purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  content_id uuid not null references public.content_items(id) on delete cascade,
  amount numeric not null default 0,
  platform_fee numeric not null default 0,
  owner_amount numeric not null default 0,
  created_at timestamp with time zone not null default now(),
  unique(user_id, content_id)
);

create table if not exists public.content_feedback_requests (
  id uuid primary key default gen_random_uuid(),
  content_id uuid not null references public.content_items(id) on delete cascade,
  learner_id uuid not null references auth.users(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  subject text,
  message text not null,
  status text not null default 'open',
  created_at timestamp with time zone not null default now()
);

alter table public.content_items enable row level security;
alter table public.content_episodes enable row level security;
alter table public.content_purchases enable row level security;
alter table public.content_feedback_requests enable row level security;

drop policy if exists "Public can view published content items" on public.content_items;
create policy "Public can view published content items"
on public.content_items for select
using (is_published = true or auth.uid() = owner_id);

drop policy if exists "Owners can insert content items" on public.content_items;
create policy "Owners can insert content items"
on public.content_items for insert
with check (auth.uid() = owner_id);

drop policy if exists "Owners can update content items" on public.content_items;
create policy "Owners can update content items"
on public.content_items for update
using (auth.uid() = owner_id);

drop policy if exists "Public can view episodes for published items" on public.content_episodes;
create policy "Public can view episodes for published items"
on public.content_episodes for select
using (
  exists (
    select 1 from public.content_items ci
    where ci.id = content_id
    and (ci.is_published = true or ci.owner_id = auth.uid())
  )
);

drop policy if exists "Owners can insert episodes" on public.content_episodes;
create policy "Owners can insert episodes"
on public.content_episodes for insert
with check (
  exists (
    select 1 from public.content_items ci
    where ci.id = content_id and ci.owner_id = auth.uid()
  )
);

drop policy if exists "Owners can update episodes" on public.content_episodes;
create policy "Owners can update episodes"
on public.content_episodes for update
using (
  exists (
    select 1 from public.content_items ci
    where ci.id = content_id and ci.owner_id = auth.uid()
  )
);

drop policy if exists "Users can view own content purchases" on public.content_purchases;
create policy "Users can view own content purchases"
on public.content_purchases for select
using (auth.uid() = user_id);

drop policy if exists "Users can insert own content purchases" on public.content_purchases;
create policy "Users can insert own content purchases"
on public.content_purchases for insert
with check (auth.uid() = user_id);

drop policy if exists "Learners can view own feedback and owners can view feedback" on public.content_feedback_requests;
create policy "Learners can view own feedback and owners can view feedback"
on public.content_feedback_requests for select
using (auth.uid() = learner_id or auth.uid() = owner_id);

drop policy if exists "Learners can create feedback requests" on public.content_feedback_requests;
create policy "Learners can create feedback requests"
on public.content_feedback_requests for insert
with check (auth.uid() = learner_id);

create index if not exists idx_content_items_owner_id on public.content_items(owner_id);
create index if not exists idx_content_items_type on public.content_items(content_type);
create index if not exists idx_content_episodes_content_id on public.content_episodes(content_id);
create index if not exists idx_content_feedback_content_id on public.content_feedback_requests(content_id);
