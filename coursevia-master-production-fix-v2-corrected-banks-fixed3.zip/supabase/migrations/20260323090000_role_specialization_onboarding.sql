-- Role specialization onboarding support

alter table public.categories
  add column if not exists role_type text;

alter table public.profiles
  add column if not exists specialization_type text,
  add column if not exists specialization_slug text,
  add column if not exists primary_category_id uuid;

alter table public.profiles
  drop constraint if exists profiles_primary_category_id_fkey;

alter table public.profiles
  add constraint profiles_primary_category_id_fkey
  foreign key (primary_category_id)
  references public.categories(id)
  on delete set null;

create index if not exists idx_categories_role_type on public.categories(role_type);
create index if not exists idx_profiles_specialization_slug on public.profiles(specialization_slug);
create index if not exists idx_profiles_primary_category_id on public.profiles(primary_category_id);
