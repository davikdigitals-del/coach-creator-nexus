-- Secure paid video access with 5-second app preview

alter table public.content_episodes
  add column if not exists video_storage_path text;

alter table public.content_episodes
  alter column video_url drop not null;

create index if not exists idx_content_episodes_storage_path
  on public.content_episodes(video_storage_path)
  where video_storage_path is not null;

alter table public.content_items
  alter column preview_seconds set default 5;

update public.content_items
set preview_seconds = 5
where content_type in ('single_video', 'episode_series')
  and (preview_seconds is null or preview_seconds <= 0 or preview_seconds > 5);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'videos',
  'videos',
  false,
  1073741824,
  array['video/mp4', 'video/webm', 'video/quicktime', 'video/x-msvideo', 'video/mpeg']
)
on conflict (id) do update
set public = false,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'thumbnails',
  'thumbnails',
  true,
  10485760,
  array['image/png', 'image/jpeg', 'image/jpg', 'image/webp']
)
on conflict (id) do update
set public = true,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

-- storage policies for private videos bucket
-- owner uploads and manages their own files

drop policy if exists "Users can upload private videos" on storage.objects;
create policy "Users can upload private videos"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'videos'
  and owner_id = auth.uid()
);

drop policy if exists "Users can read private videos" on storage.objects;
create policy "Users can read private videos"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'videos'
  and owner_id = auth.uid()
);

drop policy if exists "Users can update private videos" on storage.objects;
create policy "Users can update private videos"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'videos'
  and owner_id = auth.uid()
)
with check (
  bucket_id = 'videos'
  and owner_id = auth.uid()
);

drop policy if exists "Users can delete private videos" on storage.objects;
create policy "Users can delete private videos"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'videos'
  and owner_id = auth.uid()
);

-- thumbnails remain public for listing pages

drop policy if exists "Users can upload thumbnails public" on storage.objects;
create policy "Users can upload thumbnails public"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'thumbnails'
  and owner_id = auth.uid()
);

drop policy if exists "Public can view thumbnails" on storage.objects;
create policy "Public can view thumbnails"
on storage.objects
for select
using (bucket_id = 'thumbnails');

drop policy if exists "Users can update thumbnails public" on storage.objects;
create policy "Users can update thumbnails public"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'thumbnails'
  and owner_id = auth.uid()
)
with check (
  bucket_id = 'thumbnails'
  and owner_id = auth.uid()
);

drop policy if exists "Users can delete thumbnails public" on storage.objects;
create policy "Users can delete thumbnails public"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'thumbnails'
  and owner_id = auth.uid()
);

-- prevent free videos on unified content by enforcing positive price for video types
alter table public.content_items
  drop constraint if exists content_items_paid_video_price_check;

alter table public.content_items
  add constraint content_items_paid_video_price_check
  check (
    case
      when content_type in ('single_video', 'episode_series') then price > 0
      else price >= 0
    end
  );
