-- =========================================================
-- COURSEVIA VIDEO ACCESS SYSTEM
-- Safe single SQL file
-- =========================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'videos',
  'videos',
  false,
  1073741824,
  array['video/mp4', 'video/webm', 'video/quicktime', 'video/x-msvideo', 'video/mpeg']
)
on conflict (id) do update
set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'thumbnails',
  'thumbnails',
  true,
  10485760,
  array['image/png', 'image/jpeg', 'image/jpg', 'image/webp']
)
on conflict (id) do update
set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "Users can upload private videos" on storage.objects;
create policy "Users can upload private videos"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'videos'
  and auth.uid() is not null
);

drop policy if exists "Users can read own private videos" on storage.objects;
create policy "Users can read own private videos"
on storage.objects
for select
to authenticated
using (
  bucket_id = 'videos'
  and owner_id::text = auth.uid()::text
);

drop policy if exists "Users can update own private videos" on storage.objects;
create policy "Users can update own private videos"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'videos'
  and owner_id::text = auth.uid()::text
)
with check (
  bucket_id = 'videos'
  and owner_id::text = auth.uid()::text
);

drop policy if exists "Users can delete own private videos" on storage.objects;
create policy "Users can delete own private videos"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'videos'
  and owner_id::text = auth.uid()::text
);

drop policy if exists "Users can upload thumbnails" on storage.objects;
create policy "Users can upload thumbnails"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'thumbnails'
  and auth.uid() is not null
);

drop policy if exists "Public can view thumbnails" on storage.objects;
create policy "Public can view thumbnails"
on storage.objects
for select
using (
  bucket_id = 'thumbnails'
);

drop policy if exists "Users can update own thumbnails" on storage.objects;
create policy "Users can update own thumbnails"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'thumbnails'
  and owner_id::text = auth.uid()::text
)
with check (
  bucket_id = 'thumbnails'
  and owner_id::text = auth.uid()::text
);

drop policy if exists "Users can delete own thumbnails" on storage.objects;
create policy "Users can delete own thumbnails"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'thumbnails'
  and owner_id::text = auth.uid()::text
);

do $$
begin
  if exists (
    select 1
    from information_schema.tables
    where table_schema = 'public'
      and table_name = 'content_items'
  ) then
    alter table public.content_items
      add column if not exists preview_seconds integer;

    alter table public.content_items
      add column if not exists video_storage_path text;

    alter table public.content_items
      alter column preview_seconds set default 5;

    update public.content_items
    set preview_seconds = 5
    where content_type in ('single_video', 'episode_series')
      and (preview_seconds is null or preview_seconds <= 0 or preview_seconds > 5);

    alter table public.content_items
      drop constraint if exists content_items_paid_video_price_check;

    alter table public.content_items
      add constraint content_items_paid_video_price_check
      check (
        case
          when content_type in ('single_video', 'episode_series') then price > 0
          else price >= 0
        end
      );
  end if;
end $$;

do $$
begin
  if exists (
    select 1
    from information_schema.tables
    where table_schema = 'public'
      and table_name = 'content_episodes'
  ) then
    alter table public.content_episodes
      add column if not exists video_storage_path text;

    create index if not exists idx_content_episodes_storage_path
      on public.content_episodes(video_storage_path)
      where video_storage_path is not null;
  end if;
end $$;

do $$
begin
  if exists (
    select 1
    from information_schema.tables
    where table_schema = 'public'
      and table_name = 'videos'
  ) then
    alter table public.videos
      add column if not exists storage_path text;

    alter table public.videos
      add column if not exists preview_seconds integer default 5;

    alter table public.videos
      add column if not exists slug text;

    alter table public.videos
      add column if not exists status text default 'draft';

    alter table public.videos
      add column if not exists is_paid boolean default true;

    alter table public.videos
      add column if not exists price numeric(12,2) default 0;

    update public.videos
    set
      preview_seconds = 5,
      is_paid = true
    where preview_seconds is null
       or preview_seconds <= 0
       or preview_seconds > 5;

    update public.videos
    set is_paid = true
    where is_paid is distinct from true;

    update public.videos
    set price = 1
    where coalesce(price, 0) <= 0;

    alter table public.videos
      drop constraint if exists videos_paid_only_check;

    alter table public.videos
      add constraint videos_paid_only_check
      check (
        is_paid = true
        and price > 0
      );
  end if;
end $$;

create table if not exists public.video_purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  video_id uuid not null,
  amount numeric(12,2) not null default 0,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

create index if not exists idx_video_purchases_user_id
  on public.video_purchases(user_id);

create index if not exists idx_video_purchases_video_id
  on public.video_purchases(video_id);

create unique index if not exists idx_video_purchases_user_video_unique
  on public.video_purchases(user_id, video_id);

alter table public.video_purchases enable row level security;

drop policy if exists "Users can view own video purchases" on public.video_purchases;
create policy "Users can view own video purchases"
on public.video_purchases
for select
to authenticated
using (
  auth.uid() = user_id
);

drop policy if exists "Users can insert own video purchases" on public.video_purchases;
create policy "Users can insert own video purchases"
on public.video_purchases
for insert
to authenticated
with check (
  auth.uid() = user_id
);

drop policy if exists "Admins can manage video purchases" on public.video_purchases;
create policy "Admins can manage video purchases"
on public.video_purchases
for all
to authenticated
using (
  public.has_role(auth.uid(), 'admin'::public.app_role)
)
with check (
  public.has_role(auth.uid(), 'admin'::public.app_role)
);

create or replace function public.get_video_signed_url(
  p_storage_path text,
  p_expires_in integer default 3600
)
returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_url text;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select (storage.create_signed_url('videos', p_storage_path, p_expires_in)).signed_url
  into v_url;

  return v_url;
end;
$$;

grant execute on function public.get_video_signed_url(text, integer) to authenticated;

create or replace function public.get_video_access(
  p_video_id uuid,
  p_preview boolean default false
)
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_video record;
  v_has_access boolean := false;
  v_signed_url text;
  v_preview_seconds integer := 5;
begin
  if v_user_id is null then
    raise exception 'Not authenticated';
  end if;

  if not exists (
    select 1
    from information_schema.tables
    where table_schema = 'public'
      and table_name = 'videos'
  ) then
    raise exception 'videos table does not exist';
  end if;

  select *
  into v_video
  from public.videos
  where id = p_video_id;

  if not found then
    raise exception 'Video not found';
  end if;

  v_preview_seconds := coalesce(v_video.preview_seconds, 5);

  if coalesce(v_video.creator_id, v_video.user_id) = v_user_id then
    v_has_access := true;
  end if;

  if exists (
    select 1
    from public.video_purchases vp
    where vp.user_id = v_user_id
      and vp.video_id = p_video_id
      and vp.status = 'approved'
  ) then
    v_has_access := true;
  end if;

  if p_preview = true then
    v_signed_url := public.get_video_signed_url(v_video.storage_path, 3600);

    return json_build_object(
      'has_access', false,
      'preview_only', true,
      'preview_seconds', v_preview_seconds,
      'video_url', v_signed_url,
      'title', v_video.title,
      'message', 'Preview only'
    );
  end if;

  if v_has_access = false then
    return json_build_object(
      'has_access', false,
      'preview_only', false,
      'preview_seconds', v_preview_seconds,
      'message', 'You need to purchase this video'
    );
  end if;

  v_signed_url := public.get_video_signed_url(v_video.storage_path, 3600);

  return json_build_object(
    'has_access', true,
    'preview_only', false,
    'preview_seconds', v_preview_seconds,
    'video_url', v_signed_url,
    'title', v_video.title,
    'message', 'Access granted'
  );
end;
$$;

grant execute on function public.get_video_access(uuid, boolean) to authenticated;

do $$
begin
  if exists (
    select 1
    from information_schema.tables
    where table_schema = 'public'
      and table_name = 'content_items'
  ) then
    execute $fn$
      create or replace function public.get_content_video_access(
        p_content_id uuid,
        p_preview boolean default false
      )
      returns json
      language plpgsql
      security definer
      set search_path = public
      as $inner$
      declare
        v_user_id uuid := auth.uid();
        v_content record;
        v_has_access boolean := false;
        v_signed_url text;
        v_preview_seconds integer := 5;
      begin
        if v_user_id is null then
          raise exception 'Not authenticated';
        end if;

        select *
        into v_content
        from public.content_items
        where id = p_content_id;

        if not found then
          raise exception 'Content not found';
        end if;

        v_preview_seconds := coalesce(v_content.preview_seconds, 5);

        if v_content.owner_id = v_user_id then
          v_has_access := true;
        end if;

        if exists (
          select 1
          from public.video_purchases vp
          where vp.user_id = v_user_id
            and vp.video_id = p_content_id
            and vp.status = 'approved'
        ) then
          v_has_access := true;
        end if;

        if p_preview = true then
          v_signed_url := public.get_video_signed_url(v_content.video_storage_path, 3600);

          return json_build_object(
            'has_access', false,
            'preview_only', true,
            'preview_seconds', v_preview_seconds,
            'video_url', v_signed_url,
            'title', v_content.title,
            'message', 'Preview only'
          );
        end if;

        if v_has_access = false then
          return json_build_object(
            'has_access', false,
            'preview_only', false,
            'preview_seconds', v_preview_seconds,
            'message', 'You need to purchase this video'
          );
        end if;

        v_signed_url := public.get_video_signed_url(v_content.video_storage_path, 3600);

        return json_build_object(
          'has_access', true,
          'preview_only', false,
          'preview_seconds', v_preview_seconds,
          'video_url', v_signed_url,
          'title', v_content.title,
          'message', 'Access granted'
        );
      end;
      $inner$;
    $fn$;

    grant execute on function public.get_content_video_access(uuid, boolean) to authenticated;
  end if;
end $$;
