-- Self-service payout + learner approval + 8-day pending release

alter table public.wallets
  add column if not exists pending_balance numeric not null default 0,
  add column if not exists available_balance numeric not null default 0;

create table if not exists public.wallet_pending_releases (
  id uuid primary key default gen_random_uuid(),
  wallet_id uuid not null references public.wallets(id) on delete cascade,
  source_type text not null default 'booking',
  source_id uuid,
  amount numeric not null check (amount > 0),
  release_at timestamptz not null,
  status text not null default 'pending',
  created_at timestamptz not null default now(),
  released_at timestamptz
);

create table if not exists public.bank_accounts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  bank_name text,
  account_name text,
  account_number text,
  swift_code text,
  country text,
  currency text,
  created_at timestamptz not null default now()
);

alter table public.bank_accounts enable row level security;
alter table public.wallet_pending_releases enable row level security;

drop policy if exists "Users can manage own bank accounts" on public.bank_accounts;
create policy "Users can manage own bank accounts"
on public.bank_accounts
for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Users can view own wallet pending releases" on public.wallet_pending_releases;
create policy "Users can view own wallet pending releases"
on public.wallet_pending_releases
for select
using (
  exists (
    select 1 from public.wallets w
    where w.id = wallet_pending_releases.wallet_id
      and w.user_id = auth.uid()
  )
);

create or replace function public.release_due_pending_wallet_funds()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  release_record record;
  released_count integer := 0;
begin
  for release_record in
    select *
    from public.wallet_pending_releases
    where status = 'pending'
      and release_at <= now()
    order by release_at asc
  loop
    update public.wallets
    set pending_balance = greatest(coalesce(pending_balance, 0) - release_record.amount, 0),
        available_balance = coalesce(available_balance, 0) + release_record.amount,
        balance = coalesce(balance, 0) + release_record.amount,
        updated_at = now()
    where id = release_record.wallet_id;

    insert into public.wallet_ledger (wallet_id, amount, type, description)
    values (
      release_record.wallet_id,
      release_record.amount,
      'credit',
      'Pending earning released after 8-day hold'
    );

    update public.wallet_pending_releases
    set status = 'released',
        released_at = now()
    where id = release_record.id;

    released_count := released_count + 1;
  end loop;

  return released_count;
end;
$$;

grant execute on function public.release_due_pending_wallet_funds() to authenticated;

create or replace function public.approve_booking_completion(p_booking_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_booking public.bookings%rowtype;
  v_wallet_id uuid;
  v_amount numeric := 0;
  v_provider_user_id uuid;
begin
  select * into v_booking
  from public.bookings
  where id = p_booking_id
    and learner_id = auth.uid();

  if not found then
    raise exception 'Booking not found for this learner';
  end if;

  v_provider_user_id := v_booking.coach_id;

  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'bookings' and column_name = 'provider_user_id'
  ) then
    execute 'select coalesce(provider_user_id, coach_id) from public.bookings where id = $1'
      into v_provider_user_id
      using p_booking_id;
  end if;

  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'bookings' and column_name = 'provider_amount'
  ) then
    execute 'select coalesce(provider_amount, 0) from public.bookings where id = $1'
      into v_amount
      using p_booking_id;
  elsif exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'bookings' and column_name = 'amount'
  ) then
    execute 'select coalesce(amount, 0) from public.bookings where id = $1'
      into v_amount
      using p_booking_id;
  else
    v_amount := 0;
  end if;

  update public.bookings
  set status = 'learner_approved',
      updated_at = now()
  where id = p_booking_id;

  if v_provider_user_id is not null and v_amount > 0 then
    insert into public.wallets (user_id, currency, balance, pending_balance, available_balance)
    values (v_provider_user_id, 'USD', 0, 0, 0)
    on conflict do nothing;

    select id into v_wallet_id
    from public.wallets
    where user_id = v_provider_user_id
    limit 1;

    update public.wallets
    set pending_balance = coalesce(pending_balance, 0) + v_amount,
        updated_at = now()
    where id = v_wallet_id;

    insert into public.wallet_pending_releases (wallet_id, source_type, source_id, amount, release_at)
    values (v_wallet_id, 'booking', p_booking_id, v_amount, now() + interval '8 days');

    insert into public.wallet_ledger (wallet_id, amount, type, description)
    values (v_wallet_id, v_amount, 'credit', 'Booking approved by learner. Funds are pending for 8 days.');
  end if;

  return jsonb_build_object('ok', true, 'booking_id', p_booking_id, 'amount', v_amount);
end;
$$;

grant execute on function public.approve_booking_completion(uuid) to authenticated;

create or replace function public.self_cashout(p_amount numeric, p_bank_account_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_wallet public.wallets%rowtype;
  v_bank record;
  v_withdrawal_id uuid;
begin
  perform public.release_due_pending_wallet_funds();

  select * into v_wallet
  from public.wallets
  where user_id = auth.uid()
  limit 1;

  if not found then
    raise exception 'Wallet not found';
  end if;

  select * into v_bank
  from public.bank_accounts
  where id = p_bank_account_id
    and user_id = auth.uid();

  if not found then
    raise exception 'Payout account not found';
  end if;

  if p_amount <= 0 then
    raise exception 'Amount must be greater than zero';
  end if;

  if coalesce(v_wallet.available_balance, v_wallet.balance, 0) < p_amount then
    raise exception 'Insufficient available balance';
  end if;

  update public.wallets
  set available_balance = greatest(coalesce(available_balance, 0) - p_amount, 0),
      balance = greatest(coalesce(balance, 0) - p_amount, 0),
      updated_at = now()
  where id = v_wallet.id;

  insert into public.withdrawal_requests (
    user_id,
    wallet_id,
    amount,
    bank_name,
    account_number,
    account_name,
    status,
    processed_at,
    admin_notes
  )
  values (
    auth.uid(),
    v_wallet.id,
    p_amount,
    v_bank.bank_name,
    v_bank.account_number,
    v_bank.account_name,
    'paid',
    now(),
    'Self-service payout created by wallet owner'
  )
  returning id into v_withdrawal_id;

  insert into public.wallet_ledger (wallet_id, amount, type, description)
  values (v_wallet.id, p_amount, 'debit', 'Self-service payout sent to saved bank details');

  return jsonb_build_object('ok', true, 'withdrawal_id', v_withdrawal_id);
end;
$$;

grant execute on function public.self_cashout(numeric, uuid) to authenticated;
