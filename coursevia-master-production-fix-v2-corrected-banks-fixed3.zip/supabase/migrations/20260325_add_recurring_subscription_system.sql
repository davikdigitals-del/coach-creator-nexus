begin;

create extension if not exists pgcrypto;

create table if not exists public.billing_plans (
  id uuid primary key default gen_random_uuid(),
  plan_key text not null unique,
  name text not null,
  amount numeric(12,2) not null default 0,
  interval text not null default 'monthly',
  currency text not null default 'NGN',
  provider text not null default 'paystack',
  provider_plan_code text,
  active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique,
  plan text not null default 'learner_monthly',
  amount numeric(12,2) not null default 0,
  billing_cycle text not null default 'monthly',
  status text not null default 'inactive',
  starts_at timestamptz,
  ends_at timestamptz,
  started_at timestamptz,
  expires_at timestamptz,
  payment_provider text not null default 'paystack',
  paystack_customer_code text,
  paystack_plan_code text,
  paystack_subscription_code text,
  paystack_email_token text,
  last_payment_reference text,
  cancel_at_period_end boolean not null default false,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.subscriptions add column if not exists user_id uuid;
alter table public.subscriptions add column if not exists plan text default 'learner_monthly';
alter table public.subscriptions add column if not exists amount numeric(12,2) not null default 0;
alter table public.subscriptions add column if not exists billing_cycle text default 'monthly';
alter table public.subscriptions add column if not exists status text default 'inactive';
alter table public.subscriptions add column if not exists starts_at timestamptz;
alter table public.subscriptions add column if not exists ends_at timestamptz;
alter table public.subscriptions add column if not exists started_at timestamptz;
alter table public.subscriptions add column if not exists expires_at timestamptz;
alter table public.subscriptions add column if not exists payment_provider text default 'paystack';
alter table public.subscriptions add column if not exists paystack_customer_code text;
alter table public.subscriptions add column if not exists paystack_plan_code text;
alter table public.subscriptions add column if not exists paystack_subscription_code text;
alter table public.subscriptions add column if not exists paystack_email_token text;
alter table public.subscriptions add column if not exists last_payment_reference text;
alter table public.subscriptions add column if not exists cancel_at_period_end boolean not null default false;
alter table public.subscriptions add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.subscriptions add column if not exists created_at timestamptz not null default now();
alter table public.subscriptions add column if not exists updated_at timestamptz not null default now();

create unique index if not exists idx_subscriptions_user_id on public.subscriptions(user_id);
create index if not exists idx_subscriptions_status on public.subscriptions(status);
create index if not exists idx_subscriptions_paystack_code on public.subscriptions(paystack_subscription_code);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  payer_id uuid,
  amount numeric(12,2) not null default 0,
  currency text not null default 'NGN',
  status text not null default 'pending',
  provider text not null default 'paystack',
  payment_type text,
  payment_method text,
  reference_id text,
  reference text unique,
  provider_customer_code text,
  provider_plan_code text,
  provider_subscription_code text,
  provider_email_token text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.payments add column if not exists user_id uuid;
alter table public.payments add column if not exists payer_id uuid;
alter table public.payments add column if not exists amount numeric(12,2) not null default 0;
alter table public.payments add column if not exists currency text not null default 'NGN';
alter table public.payments add column if not exists status text not null default 'pending';
alter table public.payments add column if not exists provider text not null default 'paystack';
alter table public.payments add column if not exists payment_type text;
alter table public.payments add column if not exists payment_method text;
alter table public.payments add column if not exists reference_id text;
alter table public.payments add column if not exists reference text;
alter table public.payments add column if not exists provider_customer_code text;
alter table public.payments add column if not exists provider_plan_code text;
alter table public.payments add column if not exists provider_subscription_code text;
alter table public.payments add column if not exists provider_email_token text;
alter table public.payments add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.payments add column if not exists created_at timestamptz not null default now();
alter table public.payments add column if not exists updated_at timestamptz not null default now();

create unique index if not exists idx_payments_reference on public.payments(reference);
create index if not exists idx_payments_user_id on public.payments(coalesce(user_id, payer_id));
create index if not exists idx_payments_type on public.payments(payment_type);

commit;
