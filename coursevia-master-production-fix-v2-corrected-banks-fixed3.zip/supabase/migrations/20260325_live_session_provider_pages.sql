-- Live session support for both coach and therapist dashboards
alter table public.bookings add column if not exists provider_id uuid;
alter table public.bookings add column if not exists learner_id uuid;
alter table public.bookings add column if not exists meeting_link text;
alter table public.bookings add column if not exists session_room_url text;
alter table public.bookings add column if not exists payment_status text default 'pending';
alter table public.bookings add column if not exists paid_at timestamptz;
alter table public.bookings add column if not exists payment_reference text;
alter table public.bookings add column if not exists provider_type text;
create index if not exists idx_bookings_provider_id on public.bookings(provider_id);
create index if not exists idx_bookings_learner_id on public.bookings(learner_id);
