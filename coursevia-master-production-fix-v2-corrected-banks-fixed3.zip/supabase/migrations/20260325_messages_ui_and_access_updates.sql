alter table public.messages add column if not exists is_read boolean not null default false;

create index if not exists idx_messages_receiver_read on public.messages(receiver_id, is_read, created_at desc);
create index if not exists idx_messages_participants_created_at on public.messages(sender_id, receiver_id, created_at desc);
