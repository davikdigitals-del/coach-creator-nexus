begin;

create extension if not exists pgcrypto;

alter table public.bookings add column if not exists payment_status text default 'pending';
alter table public.bookings add column if not exists payment_reference text;
alter table public.bookings add column if not exists paid_at timestamptz;
alter table public.bookings add column if not exists meeting_link text;
alter table public.bookings add column if not exists provider_id uuid;
alter table public.bookings add column if not exists learner_id uuid;
alter table public.bookings add column if not exists session_room_url text;
alter table public.bookings add column if not exists session_starts_at timestamptz;
alter table public.bookings add column if not exists session_ends_at timestamptz;
alter table public.bookings add column if not exists session_opens_at timestamptz;
alter table public.bookings add column if not exists scheduled_at timestamptz;
alter table public.bookings add column if not exists booking_type text default 'scheduled';
alter table public.bookings add column if not exists notes text;
alter table public.bookings add column if not exists service_id uuid;

create table if not exists public.session_reminders (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null,
  user_id uuid not null,
  remind_at timestamptz not null,
  sent boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists idx_session_reminders_booking on public.session_reminders(booking_id);
create index if not exists idx_bookings_payment_status on public.bookings(payment_status);
create unique index if not exists idx_payments_reference_unique on public.payments(reference);

commit;
