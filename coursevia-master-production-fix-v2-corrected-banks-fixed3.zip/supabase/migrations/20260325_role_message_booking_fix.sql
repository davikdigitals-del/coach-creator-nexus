begin;

create extension if not exists pgcrypto;

create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role text not null,
  created_at timestamptz not null default now()
);

create unique index if not exists idx_user_roles_user_role
  on public.user_roles(user_id, role);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null,
  receiver_id uuid not null,
  content text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.messages add column if not exists sender_id uuid;
alter table public.messages add column if not exists receiver_id uuid;
alter table public.messages add column if not exists content text;
alter table public.messages add column if not exists is_read boolean not null default false;
alter table public.messages add column if not exists created_at timestamptz not null default now();

create index if not exists idx_messages_sender_receiver on public.messages(sender_id, receiver_id);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  learner_id uuid,
  provider_id uuid not null,
  service_id uuid,
  scheduled_at timestamptz,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

alter table public.bookings add column if not exists learner_id uuid;
alter table public.bookings add column if not exists provider_id uuid;
alter table public.bookings add column if not exists service_id uuid;
alter table public.bookings add column if not exists scheduled_at timestamptz;
alter table public.bookings add column if not exists status text not null default 'pending';
alter table public.bookings add column if not exists created_at timestamptz not null default now();

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  target_id uuid not null,
  target_type text not null default 'provider',
  rating integer not null default 5,
  comment text,
  created_at timestamptz not null default now()
);

alter table public.reviews add column if not exists user_id uuid;
alter table public.reviews add column if not exists target_id uuid;
alter table public.reviews add column if not exists target_type text not null default 'provider';
alter table public.reviews add column if not exists rating integer not null default 5;
alter table public.reviews add column if not exists comment text;
alter table public.reviews add column if not exists created_at timestamptz not null default now();

commit;
